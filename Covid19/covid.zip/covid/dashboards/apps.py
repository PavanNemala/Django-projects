from django.apps import AppConfig


class DashboardsConfig(AppConfig):
    name = 'dashboards'
