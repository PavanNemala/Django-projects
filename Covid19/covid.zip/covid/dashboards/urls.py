from django.urls import path
from django.conf.urls import url
from django.contrib import admin
from django.contrib.auth.views import LoginView,LogoutView
#from django_otp.forms import OTPAuthenticationForm
from . import views

urlpatterns = [
    path('', views.stats, name='stats'),
]