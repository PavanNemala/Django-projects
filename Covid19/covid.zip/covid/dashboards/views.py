from django.shortcuts import render
from django_countries import countries
import COVID19Py
import ast

# Create your views here.

def stats(request):
    covid19 = COVID19Py.COVID19()
    locations = covid19.getLocations()
    if request.method == "POST":
         name = request.POST.get("myCountry")
         if name:
             result = [i for i in locations if i["country"].lower() == name.lower()]
         else:
             result = [i for i in locations if i["country"].lower() == "India".lower()]
    countries_list =[]
    for i in countries:
        countries_list.append(i.name)
    return render(request, "stats.html",{"countryname": countries_list,"result":result})
